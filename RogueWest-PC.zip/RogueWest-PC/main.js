'use strict';
// RogueWest — Electron shell for the single-file game in /game
const {app, BrowserWindow, Menu, shell} = require('electron');
const path = require('path');

// ---- performance: always use the GPU, never throttle the game loop ----
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

// ---- only one copy of the game at a time ----
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  let win = null;

  app.on('second-instance', () => {
    if (!win) return;
    if (win.isMinimized()) win.restore();
    win.focus();
  });

  function createWindow() {
    win = new BrowserWindow({
      width: 1280,
      height: 760,
      minWidth: 640,
      minHeight: 400,
      show: false,                 // shown when ready, no white flash
      fullscreen: true,
      backgroundColor: '#160e08',
      title: 'RogueWest',
      icon: path.join(__dirname, 'game', 'icon.png'),
      autoHideMenuBar: true,
      webPreferences: {
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        backgroundThrottling: false,
        spellcheck: false
      }
    });
    Menu.setApplicationMenu(null);
    win.once('ready-to-show', () => { win.show(); win.focus(); });
    win.loadFile(path.join(__dirname, 'game', 'index.html'));

    // F11 / Alt+Enter — fullscreen toggle (in-game setting works too)
    win.webContents.on('before-input-event', (e, i) => {
      if (i.type !== 'keyDown') return;
      if (i.key === 'F11' || (i.alt && i.key === 'Enter')) {
        win.setFullScreen(!win.isFullScreen());
        e.preventDefault();
      }
    });

    // links open in the normal browser, the game window never navigates away
    win.webContents.setWindowOpenHandler(({url}) => {
      if (/^https?:/i.test(url)) shell.openExternal(url);
      return {action: 'deny'};
    });
    win.webContents.on('will-navigate', (e, url) => {
      if (!url.startsWith('file:')) { e.preventDefault(); if (/^https?:/i.test(url)) shell.openExternal(url); }
    });

    // if the renderer ever crashes, quietly reload instead of a black window
    win.webContents.on('render-process-gone', (_e, d) => {
      if (d.reason !== 'clean-exit' && win && !win.isDestroyed()) win.reload();
    });

    win.on('closed', () => { win = null; });
  }

  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
}
